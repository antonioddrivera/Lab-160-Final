public class BlankTea implements Tea{
    @Override
    public void addBoba(Tea tea) {
    }

    @Override
    public String printTea() {
        return null;
    }

    @Override
    public Double tCost() {
        return null;
    }
}
