public interface Tea {
    void addBoba(Tea tea);
    String printTea();
    Double tCost();
}
