public class Hot extends TeaDecorator{
    public Hot(Tea tea) {
        super(tea);
    }

    @Override
    public void addBoba(Tea tea) {
    }

    @Override
    public String printTea(){
        return "Hot " + this.tea.printTea();
    }
    @Override
    public Double tCost() {
        return this.tea.tCost();
    }
}
