public class BlackTea extends TeaDecorator{

    public BlackTea(Tea tea) {
        super(tea);
    }

    @Override
    public void addBoba(Tea tea) {
    }

    @Override
    public String printTea() {
        return "Black Tea";
    }

    @Override
    public Double tCost() {
        return 3.00;
    }
}
