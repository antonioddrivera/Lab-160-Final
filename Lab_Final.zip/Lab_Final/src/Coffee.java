public interface Coffee {

    void addTopping(Coffee coffee);
    String printCoffee();
    //Double cost = Double.valueOf(0);
    Double cost();
}
