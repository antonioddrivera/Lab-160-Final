public class Oolong extends TeaDecorator{

    public Oolong(Tea tea) {
        super(tea);
    }

    @Override
    public void addBoba(Tea tea) {
    }

    @Override
    public String printTea() {
        return "Oolong Tea";
    }

    @Override
    public Double tCost() {
        return 3.00;
    }
}
