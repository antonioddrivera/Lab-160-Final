public abstract class TeaDecorator implements Tea{
    protected Tea tea;

    public TeaDecorator(Tea tea){
        this.tea = tea;
    }

    public void addBoba(){
        this.tea.addBoba(tea);
    }

    public String printTea() {
        return this.tea.printTea();
    }

    public abstract Double tCost();
}
