public class Boba extends TeaDecorator{
    public Boba(Tea tea) {
        super(tea);
    }

    @Override
    public void addBoba(Tea tea) {
        tea.addBoba(this.tea);

    }

    @Override
    public String printTea(){
        return this.tea.printTea() + " with Boba";
    }
    @Override
    public Double tCost(){
        return this.tea.tCost() + .75;
    }
}
