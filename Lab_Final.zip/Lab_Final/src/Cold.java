public class Cold extends TeaDecorator{
    public Cold(Tea tea) {
        super(tea);
    }

    @Override
    public void addBoba(Tea tea) {
    }

    @Override
    public String printTea(){
        return "Iced " + this.tea.printTea();
    }
    @Override
    public Double tCost() {
        return this.tea.tCost();
    }
}
