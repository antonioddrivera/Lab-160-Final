/**
 * The driver for the entire Coffee Ordering System
 * CS 160L-1
 * @author Antonio Rivera
 * @date 6/30/2022
 */
import java.io.*;
import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {
    static int[] inventory;

    /**
     * Main method for the Ordering System. Provides different options for the user to select
     * @param args the arguments from the command line
     * @throws IOException Bc we read a file to get our updated inventory.
     */
    public static void main(String[] args) throws IOException {
        ArrayList<String> Item = new ArrayList<>();
        ArrayList<String> teaItem = new ArrayList<>();
        ArrayList<Double> price = new ArrayList<>();
        ArrayList<Double> teaPrice = new ArrayList<>();
        ArrayList<String> Temp2 = new ArrayList<>();
        Scanner userOrders = new Scanner(System.in);
        Stack<String> stack = new Stack<String>();

        Scanner CafeApplication = new Scanner(System.in);

            System.out.println("Cafe Application Running...");
            int input = 0;
            while (input != 1){
                System.out.println("Press 1 : Read Inventory");
                System.out.println("Press 2 : Create Coffee Order");
                System.out.println("Press 3 : Order Tea");
                System.out.println("Press 4 : Update Inventory");
                System.out.println("Press 5 : Update log file");
                System.out.println("Press 6 : Exit the application");
                switch (CafeApplication.nextLine()){
                    case "1":
                        inventory = inventoryReader();
                        System.out.println();
                        break;
                    case "2":
                        if(inventory[0] == 0) {
                            System.out.println("Out of Coffee. Visit us Later");
                            System.out.println();
                        }
                        else {
                            String line = "yes" ;
                            System.out.println("Coffee order created. Select toppings for the first coffee:");
                            do {
                                Temp2 = CreateOrder();
                                Item.add(Temp2.get(0));
                                String temp = Temp2.get(1);
                                Double tempToDouble = Double.parseDouble(temp);
                                price.add(tempToDouble);
                                if(inventory[0] == 0){
                                    System.out.println("Order Completed. No more coffees.");
                                    System.out.println();
                                    break;
                                }
                                System.out.println("Do you want to add another coffee to this order? - yes or no");
                            } while (!(userOrders.nextLine()).equals("no"));

                            stack.push(Main.PrintOrder(Item,price));
                        }
                        System.out.println();
                        break;
                    case "3":
                        if(inventory[6] == 0 && inventory[7] == 0 && inventory[8] == 0){
                            System.out.println("Sorry Out of Tea. Try again at another time!\n");

                    }
                        else{
                            String line = "yes";
                            System.out.println("Please select the tea base you'd like.\n");
                            do{
                                Temp2 = createTeaOrder();
                                teaItem.add(Temp2.get(0));
                                String temp = Temp2.get(1);
                                Double tempToDouble = Double.parseDouble(temp);
                                teaPrice.add(tempToDouble);
                                if(inventory[6]==0 && inventory[7]==0 && inventory[8]==0) {
                                    System.out.println("Order Completed. No more teas.\n");
                                    break;
                                }
                                System.out.println("Do you want to add another tea to this order? - yes or no\n");
                            } while (!(userOrders.nextLine()).equals("no"));
                            stack.push(Main.PrintOrder(teaItem,teaPrice));
                        }
                        break;
                    case "4":
                        inventoryWriter(inventory);
                        break;
                    case "5":
                        logWriter(stack);
                        System.out.println();
                        break;
                    case "6":
                        inventoryWriter(inventory);
                        logWriter(stack);
                        input = 1;
                        System.out.println();
                        break;
                    default:
                        System.out.println("Invalid Selection.Please Try Again\n");
                }
            }

    }

    /**
     * Prints the order for both coffee and tea and converts Arraylists of both the item and price into a string
     * to be written into the log file later.
     * @param Item The ArrayList containing the item with toppings.
     * @param price The ArrayList containing the price for the iteam.
     * @return The string that will be used by logWriter to print the receipt in a separate file.
     */
    public static String PrintOrder(ArrayList<String> Item, ArrayList<Double>
            price){
        StringBuilder str = new StringBuilder();
        Iterator<String> item = Item.iterator();
        Iterator<Double> cost = price.iterator();
        NumberFormat format = new DecimalFormat("#0.00");

        int i;
        double $ = 0;
        double sum = 0;
        for(i=0; i<Item.size(); ++i){
            $ = cost.next();
            sum += $;
            str.append("Item " + (i+1) + ": " + item.next() + " | cost: " + format.format($) + "\n");
        }

        str.append("TOTAL COST OF ORDER:" + format.format(sum));
        return str.toString();
    }

    /**
     * Create each offer item based on a series of switch cases that prompt responses from the user.
     * @return Returns an ArrayList with the coffee order placed inside
     */
    public static ArrayList<String> CreateOrder(){
        Scanner userFeedback = new Scanner(System.in);
        ArrayList<String> coffeeOrder = new ArrayList<String> ();
        Coffee basicCoffee = new BasicCoffee();
        inventory[0]--;


        int in = 0;
        while (in != 1) {
            System.out.println("For Milk, press 1");
            System.out.println("For Hot Water, press 2");
            System.out.println("For Espresso, press 3");
            System.out.println("For Sugar, press 4");
            System.out.println("For Whipped Cream, press 5");
            System.out.println("To Complete Order, press e");
            String test = userFeedback.nextLine();

            switch(test){
                case "1":
                    if(inventory[1] == 0){
                        System.out.println("Out of milk. Try a different topping.");
                    }
                    else {
                        basicCoffee = new Milk(basicCoffee);
                        inventory[1]--;
                    }
                    break;
                case "2":
                    if(inventory[2] == 0) {
                        System.out.println("Out of Hot Water. Try a different topping.");
                    }
                    else {
                        basicCoffee = new HotWater(basicCoffee);
                        inventory[2]--;
                    }
                    break;
                case "3":
                    if(inventory[3] == 0)
                        System.out.println("Out of Espresso. Try a different topping.");
                    else {
                        basicCoffee = new Espresso(basicCoffee);
                        inventory[3]--;
                    }
                    break;
                case "4":
                    if(inventory[4] == 0)
                        System.out.println("Out of sugar. Try a different topping.");
                    else {
                        basicCoffee = new Sugar(basicCoffee);
                        inventory[4]--;
                    }
                    break;
                case "5":
                    if(inventory[5] == 0)
                        System.out.println("Out of whipped cream. Try a different topping");
                    else {
                        basicCoffee = new WhippedCream(basicCoffee);
                        inventory[5]--;
                    }
                    break;
                case "e", "E":
                    in = 1;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
                    break;
            }

        }
        coffeeOrder.add(basicCoffee.printCoffee());
        Double cost = coffeeCost(basicCoffee);
        String costToString = cost.toString();
        coffeeOrder.add(costToString);
        return coffeeOrder;
    }

    /**
     * Gets the cost of coffee and returns as a Double to be converted to String to be
     * placed in arraylist from CreateOrder
     * @param coffee is the coffee item with toppings already selected
     * @return returns the cost of the item
     */
    public static Double coffeeCost (Coffee coffee){
        return coffee.cost();
    }

    /**
     * Reads the inventory file to get the current stock values
     * @return Returns an array that contains the number for each item on the menu
     * @throws FileNotFoundException In case "inventory.txt" is missing from the folder
     */
    public static int[] inventoryReader() throws FileNotFoundException {
        inventory = new int[10];
        int[] array = new int[10];
        try {
            FileReader file = new FileReader("inventory.txt");
            BufferedReader reader = new BufferedReader(file);
            for(int i=0; i<10; i++) {
                String line = reader.readLine();
                System.out.println(line);
                String[] num = line.split("= ");
                array[i] = Integer.parseInt(num[1]);
            }


        }
        catch (FileNotFoundException e){
            throw new RuntimeException();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return array;
    }

    /**
     * Updates the inventory after creating coffees and teas on request or upon exiting the application
     * @param inventory The established inventory array that was returned in inventoryReader
     * @throws IOException In case "inventory.txt" is not file in the folder
     */
    public static void inventoryWriter(int[] inventory) throws IOException {
        try {
            if(inventory == null)
                System.out.println("Nothing to update");
            else {
                FileWriter writer = new FileWriter("inventory.txt", false);
                writer.write("Black Coffee = " + inventory[0] + "\n");
                writer.write("Milk = " + inventory[1] + "\n");
                writer.write("HotWater = " + inventory[2] + "\n");
                writer.write("Espresso = " + inventory[3] + "\n");
                writer.write("Sugar = " + inventory[4] + "\n");
                writer.write("WhippedCream = " + inventory[5] + "\n");
                writer.write("Black Tea = " + inventory[6] + "\n");
                writer.write("Green Tea = " + inventory[7] + "\n");
                writer.write("Oolong Tea = " + inventory[8] + "\n");
                writer.write("Boba = " + inventory[9]);
                writer.flush();
                writer.close();
                System.out.println("Successfully updated the inventory");
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    /**
     * Write the orders, times, date, and price in the log file
     * @param stack Stack that contains the orders with price
     */
    public static void logWriter(Stack<String> stack){
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
        Date date = new Date(System.currentTimeMillis());


        try {
            FileWriter fWrite = new FileWriter("LogFile.txt", true);
            fWrite.write("\n\nWriting orders froms stack " + format.format(date));

            if(stack.isEmpty()){
                System.out.println("Nothing to log. Stack is empty");
            }
            else {
                while (!stack.isEmpty()) {
                    fWrite.write("\nRECEIPT\n");
                    fWrite.write(stack.pop());
                    fWrite.write("\n");
                }
                fWrite.flush();
                fWrite.close();
                System.out.println("successfully updated the log file");
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * Asks the user different questions in order to get a tea item
     * @return an object from Tea that has boba and desired temperature as asked for
     */
    public static ArrayList<String> createTeaOrder(){
        Scanner userFeedback = new Scanner(System.in);
        ArrayList<String> teaOrder = new ArrayList<String> ();
        Tea newTea = new BlankTea();

        String test;
        if (inventory[6]==0 && inventory[7] ==0 && inventory[8] == 0) {
            System.out.println("Out of Tea.");
            return null;
        } else {
            int in = 0;
           while (in != 1) {
               System.out.println("For Black Tea, press 1");
               System.out.println("For Green Tea, press 2");
               System.out.println("For Oolong Tea, press 3");
               test = userFeedback.nextLine();

                switch (test) {
                    case "1":
                        if (inventory[6] == 0) {
                            System.out.println("Out of Black Tea.");
                        } else {
                            newTea = new BlackTea(newTea);
                            inventory[6]--;
                            in = 1;
                        }
                        break;
                    case "2":
                        if (inventory[7] == 0) {
                            System.out.println("Out of Green.");
                        } else {
                            newTea = new GreenTea(newTea);
                            inventory[7]--;
                            in = 1;
                        }
                        break;
                    case "3":
                        if (inventory[8] == 0)
                            System.out.println("Out of Oolong.");
                        else {
                            newTea = new Oolong(newTea);
                            inventory[8]--;
                            in = 1;
                        }
                        break;
                    default:
                        System.out.println("Invalid choice. Try again.");
                        break;
                }
            }
        }
        System.out.println("Would you like that iced or hot?");
        int in = 0;
        while(in != 1){
            test = userFeedback.nextLine();
            switch (test) {
                case "iced", "ICED" -> {
                    newTea = new Cold(newTea);
                    in = 1;
                }
                case "hot", "HOT" -> {
                    newTea = new Hot(newTea);
                    in = 1;
                }
                default -> System.out.println("Invalid choice. Try again");
            }
        }
        System.out.println("Would you like to add boba to your tea? Yes or No?");
        in = 0;
        while(in != 1){
            test = userFeedback.nextLine();
            switch (test){
                case "yes":
                case "Yes":
                case "YES":
                case "y":
                case "Y":
                    if (inventory[9] == 0)
                        System.out.println("Sorry, out of boba");
                    else{
                        newTea = new Boba(newTea);
                        inventory[9]--;
                        in = 1;
                    }
                    break;
                case "no":
                case "No":
                case "NO":
                case "n":
                case "N":
                    in = 1;
                    break;
                default:
                    System.out.println("Not a valid choice");
            }
        }
        teaOrder.add(newTea.printTea());
        Double cost = teaCost(newTea);
        String costToString = cost.toString();
        teaOrder.add(costToString);
        return teaOrder;
    }

    /**
     * Gets the cost of tea and returns as a Double to be converted to String to be
     * placed in arraylist from createTeOrder
     * @param tea
     * @return This method will return a double of the cost
     */
    public static Double teaCost (Tea tea){
        return tea.tCost();
    }
}